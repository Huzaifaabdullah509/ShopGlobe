
import { Link } from 'react-router-dom';
import { Heart, ShoppingCart } from 'lucide-react';
import { useCart } from '../../contexts/CartContext';
import { toast } from 'sonner';

type ProductCardProps = {
  product: {
    id: string;
    title: string;
    slug: string;
    price: number;
    compare_at_price: number | null;
    images: { url: string; alt: string }[];
  };
};

const ProductCard = ({ product }: ProductCardProps) => {
  const { addItem } = useCart();
  const { title, slug, price, compare_at_price, images } = product;
  
  const imageUrl = images && images.length > 0 ? images[0].url : 'https://via.placeholder.com/300';
  const imageAlt = images && images.length > 0 ? images[0].alt : title;
  
  const discountPercentage = compare_at_price
    ? Math.round(((compare_at_price - price) / compare_at_price) * 100)
    : null;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(product.id);
  };

  const handleAddToWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toast.info('Feature coming soon: Add to wishlist');
  };

  return (
    <Link to={`/products/${slug}`} className="group">
      <div className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-300">
        <div className="relative h-48 sm:h-64 overflow-hidden">
          <img
            src={imageUrl}
            alt={imageAlt}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          
          {discountPercentage && (
            <div className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
              {discountPercentage}% OFF
            </div>
          )}
          
          <div className="absolute top-2 right-2 flex flex-col space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={handleAddToWishlist}
              className="bg-white p-2 rounded-full shadow hover:bg-gray-100"
            >
              <Heart size={18} className="text-gray-600" />
            </button>
            <button
              onClick={handleAddToCart}
              className="bg-white p-2 rounded-full shadow hover:bg-gray-100"
            >
              <ShoppingCart size={18} className="text-gray-600" />
            </button>
          </div>
        </div>
        
        <div className="p-4">
          <h3 className="text-gray-800 font-medium mb-1 line-clamp-2">{title}</h3>
          <div className="flex items-center">
            <span className="text-gray-900 font-bold">${price.toFixed(2)}</span>
            {compare_at_price && (
              <span className="text-gray-500 line-through text-sm ml-2">
                ${compare_at_price.toFixed(2)}
              </span>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;