
import { useState } from 'react';
import { Bell, Search, Menu } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const DashboardHeader = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const { profile } = useAuth();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement dashboard search functionality
    console.log('Searching for:', searchQuery);
  };

  return (
    <header className="bg-white shadow-sm h-16 flex items-center px-6">
      <button className="md:hidden mr-4">
        <Menu size={24} />
      </button>
      
      <form onSubmit={handleSearch} className="flex-1 max-w-xl relative">
        <input
          type="text"
          placeholder="Search..."
          className="w-full py-2 px-4 pr-10 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button
          type="submit"
          className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-blue-500"
        >
          <Search size={20} />
        </button>
      </form>
      
      <div className="ml-4 flex items-center">
        <div className="relative mr-4">
          <Bell size={20} className="text-gray-600 hover:text-blue-600 cursor-pointer" />
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
            3
          </span>
        </div>
        
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-sm font-semibold mr-2">
            {profile?.full_name ? profile.full_name[0].toUpperCase() : 'U'}
          </div>
          <span className="text-gray-700 font-medium hidden md:block">
            {profile?.full_name || 'User'}
          </span>
        </div>
      </div>
    </header>
  );
};

export default DashboardHeader;