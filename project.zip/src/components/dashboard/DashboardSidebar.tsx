
import { Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  Package, 
  Users, 
  BarChart, 
  Settings, 
  ShoppingBag,
  LogOut
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const DashboardSidebar = () => {
  const location = useLocation();
  const { profile, signOut } = useAuth();
  
  const isAdmin = profile?.role === 'admin';
  
  const navItems = [
    { 
      name: 'Dashboard', 
      path: '/dashboard', 
      icon: <Home size={20} /> 
    },
    { 
      name: 'Products', 
      path: '/dashboard/products', 
      icon: <ShoppingBag size={20} /> 
    },
    { 
      name: 'Orders', 
      path: '/dashboard/orders', 
      icon: <Package size={20} /> 
    },
    { 
      name: 'Analytics', 
      path: '/dashboard/analytics', 
      icon: <BarChart size={20} /> 
    },
    // Only show Customers to admins
    ...(isAdmin ? [{ 
      name: 'Customers', 
      path: '/dashboard/customers', 
      icon: <Users size={20} /> 
    }] : []),
    { 
      name: 'Settings', 
      path: '/dashboard/settings', 
      icon: <Settings size={20} /> 
    },
  ];

  const isActive = (path: string) => {
    if (path === '/dashboard') {
      return location.pathname === path;
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="w-64 bg-gray-900 text-white h-full flex flex-col">
      <div className="p-4 border-b border-gray-800">
        <Link to="/" className="flex items-center">
          <span className="text-xl font-bold text-white">ShopGlobe</span>
        </Link>
      </div>
      
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center text-lg font-semibold">
            {profile?.full_name ? profile.full_name[0].toUpperCase() : 'U'}
          </div>
          <div className="ml-3">
            <p className="font-medium">{profile?.full_name || 'User'}</p>
            <p className="text-sm text-gray-400 capitalize">{profile?.role || 'User'}</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4 overflow-y-auto">
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.path}>
              <Link
                to={item.path}
                className={`flex items-center px-4 py-3 rounded-md transition-colors ${
                  isActive(item.path)
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-300 hover:bg-gray-800'
                }`}
              >
                <span className="mr-3">{item.icon}</span>
                {item.name}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-gray-800">
        <button
          onClick={() => signOut()}
          className="flex items-center w-full px-4 py-3 text-gray-300 hover:bg-gray-800 rounded-md transition-colors"
        >
          <LogOut size={20} className="mr-3" />
          Sign Out
        </button>
      </div>
    </div>
  );
};

export default DashboardSidebar;