
import { Link } from 'react-router-dom';

const NotFoundPage = () => {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <h1 className="text-9xl font-bold text-gray-200">404</h1>
      <div className="absolute">
        <div className="px-4 py-2 bg-white rounded-full">
          <h2 className="text-2xl font-bold text-gray-800">Page Not Found</h2>
        </div>
      </div>
      <p className="mt-16 mb-8 text-gray-600 max-w-md">
        The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
      </p>
      <Link
        to="/"
        className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md"
      >
        Back to Homepage
      </Link>
    </div>
  );
};

export default NotFoundPage;