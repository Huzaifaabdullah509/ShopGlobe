
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../App';
import { toast } from 'sonner';
import { CreditCard, Truck, Check, ChevronRight } from 'lucide-react';
import LoadingSpinner from '../components/ui/LoadingSpinner';

type ShippingAddress = {
  fullName: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone: string;
};

type PaymentMethod = {
  cardNumber: string;
  cardholderName: string;
  expiryDate: string;
  cvv: string;
};

const CheckoutPage = () => {
  const { items, subtotal, clearCart, isLoading: cartLoading } = useCart();
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  
  const [step, setStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Shipping information
  const [shippingAddress, setShippingAddress] = useState<ShippingAddress>({
    fullName: profile?.full_name || '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'United States',
    phone: '',
  });
  
  // Payment information
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>({
    cardNumber: '',
    cardholderName: '',
    expiryDate: '',
    cvv: '',
  });
  
  // Shipping options
  const shippingOptions = [
    { id: 'standard', name: 'Standard Shipping', price: subtotal >= 50 ? 0 : 5.99, days: '3-5' },
    { id: 'express', name: 'Express Shipping', price: 12.99, days: '1-2' },
  ];
  
  const [selectedShipping, setSelectedShipping] = useState(shippingOptions[0].id);
  
  // Calculate totals
  const shippingCost = shippingOptions.find(option => option.id === selectedShipping)?.price || 0;
  const taxRate = 0.08;
  const taxAmount = subtotal * taxRate;
  const total = subtotal + shippingCost + taxAmount;
  
  // Redirect if cart is empty
  useEffect(() => {
    if (!cartLoading && items.length === 0) {
      navigate('/cart');
      toast.error('Your cart is empty');
    }
  }, [items, cartLoading, navigate]);
  
  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      navigate('/login?redirect=/checkout');
      toast.error('Please sign in to checkout');
    }
  }, [user, navigate]);
  
  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Validate shipping form
    if (!shippingAddress.fullName || !shippingAddress.addressLine1 || !shippingAddress.city || 
        !shippingAddress.state || !shippingAddress.postalCode || !shippingAddress.country || !shippingAddress.phone) {
      toast.error('Please fill in all required fields');
      return;
    }
    setStep(2);
  };
  
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Validate payment form
    if (!paymentMethod.cardNumber || !paymentMethod.cardholderName || 
        !paymentMethod.expiryDate || !paymentMethod.cvv) {
      toast.error('Please fill in all payment details');
      return;
    }
    setStep(3);
  };
  
  const handlePlaceOrder = async () => {
    if (!user) {
      toast.error('Please sign in to place an order');
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // Create order in database
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: user.id,
          status: 'pending',
          total_amount: total,
          shipping_address: shippingAddress,
          billing_address: shippingAddress, // Using same address for billing
          shipping_method: selectedShipping,
          shipping_cost: shippingCost,
          tax_amount: taxAmount,
          payment_status: 'pending',
        })
        .select('id')
        .single();
      
      if (orderError) throw orderError;
      
      // Create order items
      const orderItems = items.map(item => ({
        order_id: order.id,
        product_id: item.product_id,
        product_snapshot: item.product,
        quantity: item.quantity,
        unit_price: item.product.price,
        total_price: item.product.price * item.quantity,
      }));
      
      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);
      
      if (itemsError) throw itemsError;
      
      // Clear cart
      await clearCart();
      
      // Redirect to success page
      navigate(`/orders/${order.id}?success=true`);
      
    } catch (error) {
      console.error('Error placing order:', error);
      toast.error('Failed to place order. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };
  
  if (cartLoading) {
    return <LoadingSpinner />;
  }
  
  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">Checkout</h1>
      
      {/* Checkout Steps */}
      <div className="mb-8">
        <div className="flex items-center">
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
            step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            {step > 1 ? <Check size={16} /> : 1}
          </div>
          <div className={`flex-1 h-1 mx-2 ${step >= 2 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
            step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            {step > 2 ? <Check size={16} /> : 2}
          </div>
          <div className={`flex-1 h-1 mx-2 ${step >= 3 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
            step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            3
          </div>
        </div>
        <div className="flex justify-between mt-2 text-sm">
          <div className={step >= 1 ? 'text-blue-600 font-medium' : 'text-gray-600'}>Shipping</div>
          <div className={step >= 2 ? 'text-blue-600 font-medium' : 'text-gray-600'}>Payment</div>
          <div className={step >= 3 ? 'text-blue-600 font-medium' : 'text-gray-600'}>Review</div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Checkout Form */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            {/* Step 1: Shipping Information */}
            {step === 1 && (
              <form onSubmit={handleShippingSubmit}>
                <div className="p-6 border-b border-gray-200">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <Truck size={20} className="mr-2" />
                    Shipping Information
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                      <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">
                        Full Name *
                      </label>
                      <input
                        id="fullName"
                        type="text"
                        value={shippingAddress.fullName}
                        onChange={(e) => setShippingAddress({...shippingAddress, fullName: e.target.value})}
                        className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label htmlFor="addressLine1" className="block text-sm font-medium text-gray-700 mb-1">
                        Address Line 1 *
                      </label>
                      <input
                        id="addressLine1"
                        type="text"
                        value={shippingAddress.addressLine1}
                        onChange={(e) => setShippingAddress({...shippingAddress, addressLine1: e.target.value})}
                        className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label htmlFor="addressLine2" className="block text-sm font-medium text-gray-700 mb-1">
                        Address Line 2
                      </label>
                      <input
                        id="addressLine2"
                        type="text"
                        value={shippingAddress.addressLine2}
                        onChange={(e) => setShippingAddress({...shippingAddress, addressLine2: e.target.value})}
                        className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                        City *
                      </label>
                      <input
                        id="city"
                        type="text"
                        value={shippingAddress.city}
                        onChange={(e) => setShippingAddress({...shippingAddress, city: e.target.value})}
                        className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-1">
                        State/Province *
                      </label>
                      <input
                        id="state"
                        type="text"
                        value={shippingAddress.state}
                        onChange={(e) => setShippingAddress({...shippingAddress, state: e.target.value})}
                        className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="postalCode" className="block text-sm font-medium text-gray-700 mb-1">
                        Postal Code *
                      </label>
                      <input
                        id="postalCode"
                        type="text"
                        value={shippingAddress.postalCode}
                        onChange={(e) => setShippingAddress({...shippingAddress, postalCode: e.target.value})}
                        className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="country" className="block text-sm font-medium text-gray-700 mb-1">
                        Country *
                      </label>
                      <select
                        id="country"
                        value={shippingAddress.country}
                        onChange={(e) => setShippingAddress({...shippingAddress, country: e.target.value})}
                        className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      >
                        <option value="United States">United States</option>
                        <option value="Canada">Canada</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="Australia">Australia</option>
                        <option value="Germany">Germany</option>
                        <option value="France">France</option>
                      </select>
                    </div>
                    
                    <div className="md:col-span-2">
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                        Phone Number *
                      </label>
                      <input
                        id="phone"
                        type="tel"
                        value={shippingAddress.phone}
                        onChange={(e) => setShippingAddress({...shippingAddress, phone: e.target.value})}
                        className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                  </div>
                </div>
                
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-semibold mb-4">Shipping Method</h3>
                  
                  <div className="space-y-3">
                    {shippingOptions.map((option) => (
                      <div key={option.id} className="flex items-center">
                        <input
                          id={`shipping-${option.id}`}
                          type="radio"
                          name="shipping"
                          value={option.id}
                          checked={selectedShipping === option.id}
                          onChange={() => setSelectedShipping(option.id)}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                        />
                        <label htmlFor={`shipping-${option.id}`} className="ml-3 flex flex-1 justify-between">
                          <div>
                            <span className="block text-sm font-medium text-gray-900">{option.name}</span>
                            <span className="block text-sm text-gray-500">{option.days} business days</span>
                          </div>
                          <span className="text-sm font-medium text-gray-900">
                            {option.price === 0 ? 'Free' : `$${option.price.toFixed(2)}`}
                          </span>
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="p-6 flex justify-end">
                  <button
                    type="submit"
                    className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-md flex items-center"
                  >
                    Continue to Payment
                    <ChevronRight size={16} className="ml-1" />
                  </button>
                </div>
              </form>
            )}
            
            {/* Step 2: Payment Information */}
            {step === 2 && (
              <form onSubmit={handlePaymentSubmit}>
                <div className="p-6 border-b border-gray-200">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <CreditCard size={20} className="mr-2" />
                    Payment Information
                  </h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700 mb-1">
                        Card Number *
                      </label>
                      <input
                        id="cardNumber"
                        type="text"
                        value={paymentMethod.cardNumber}
                        onChange={(e) => setPaymentMethod({...paymentMethod, cardNumber: e.target.value})}
                        placeholder="1234 5678 9012 3456"
                        className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="cardholderName" className="block text-sm font-medium text-gray-700 mb-1">
                        Cardholder Name *
                      </label>
                      <input
                        id="cardholderName"
                        type="text"
                        value={paymentMethod.cardholderName}
                        onChange={(e) => setPaymentMethod({...paymentMethod, cardholderName: e.target.value})}
                        className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700 mb-1">
                          Expiry Date (MM/YY) *
                        </label>
                        <input
                          id="expiryDate"
                          type="text"
                          value={paymentMethod.expiryDate}
                          onChange={(e) => setPaymentMethod({...paymentMethod, expiryDate: e.target.value})}
                          placeholder="MM/YY"
                          className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          required
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="cvv" className="block text-sm font-medium text-gray-700 mb-1">
                          CVV *
                        </label>
                        <input
                          id="cvv"
                          type="text"
                          value={paymentMethod.cvv}
                          onChange={(e) => setPaymentMethod({...paymentMethod, cvv: e.target.value})}
                          placeholder="123"
                          className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="p-6 flex justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="text-gray-600 hover:text-gray-800"
                  >
                    Back to Shipping
                  </button>
                  
                  <button
                    type="submit"
                    className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-md flex items-center"
                  >
                    Review Order
                    <ChevronRight size={16} className="ml-1" />
                  </button>
                </div>
              </form>
            )}
            
            {/* Step 3: Review Order */}
            {step === 3 && (
              <div>
                <div className="p-6 border-b border-gray-200">
                  <h2 className="text-lg font-semibold mb-4">Review Your Order</h2>
                  
                  {/* Shipping Information Summary */}
                  <div className="mb-6">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-medium">Shipping Information</h3>
                      <button
                        onClick={() => setStep(1)}
                        className="text-sm text-blue-600 hover:text-blue-800"
                      >
                        Edit
                      </button>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-md">
                      <p className="font-medium">{shippingAddress.fullName}</p>
                      <p>{shippingAddress.addressLine1}</p>
                      {shippingAddress.addressLine2 && <p>{shippingAddress.addressLine2}</p>}
                      <p>{shippingAddress.city}, {shippingAddress.state} {shippingAddress.postalCode}</p>
                      <p>{shippingAddress.country}</p>
                      <p>{shippingAddress.phone}</p>
                    </div>
                  </div>
                  
                  {/* Payment Information Summary */}
                  <div className="mb-6">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-medium">Payment Information</h3>
                      <button
                        onClick={() => setStep(2)}
                        className="text-sm text-blue-600 hover:text-blue-800"
                      >
                        Edit
                      </button>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-md">
                      <p>Card ending in {paymentMethod.cardNumber.slice(-4)}</p>
                      <p>{paymentMethod.cardholderName}</p>
                      <p>Expires {paymentMethod.expiryDate}</p>
                    </div>
                  </div>
                  
                  {/* Order Items */}
                  <div>
                    <h3 className="font-medium mb-2">Order Items</h3>
                    
                    <div className="divide-y divide-gray-200">
                      {items.map((item) => (
                        <div key={item.id} className="py-3 flex items-center">
                          <div className="w-16 h-16 mr-4">
                            <img
                              src={item.product.images?.[0]?.url || 'https://via.placeholder.com/150'}
                              alt={item.product.title}
                              className="w-full h-full object-cover rounded-md"
                            />
                          </div>
                          
                          <div className="flex-1">
                            <p className="font-medium">{item.product.title}</p>
                            <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                          </div>
                          
                          <div className="text-right">
                            <p className="font-medium">${(item.product.price * item.quantity).toFixed(2)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="p-6 flex justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="text-gray-600 hover:text-gray-800"
                  >
                    Back to Payment
                  </button>
                  
                  <button
                    type="button"
                    onClick={handlePlaceOrder}
                    disabled={isProcessing}
                    className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-md flex items-center disabled:opacity-50"
                  >
                    {isProcessing ? 'Processing...' : 'Place Order'}
                    {!isProcessing && <ChevronRight size={16} className="ml-1" />}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm p-6 sticky top-20">
            <h2 className="text-lg font-bold mb-4">Order Summary</h2>
            
            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal ({items.length} {items.length === 1 ? 'item' : 'items'})</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Shipping</span>
                {shippingCost === 0 ? (
                  <span className="text-green-600">Free</span>
                ) : (
                  <span>${shippingCost.toFixed(2)}</span>
                )}
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tax (8%)</span>
                <span>${taxAmount.toFixed(2)}</span>
              </div>
              <div className="border-t border-gray-200 pt-3 flex justify-between font-bold">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>
            
            {/* Order Items Summary */}
            <div>
              <h3 className="font-medium mb-2 text-sm">Items in Your Order</h3>
              
              <div className="max-h-60 overflow-y-auto space-y-3">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center">
                    <div className="w-10 h-10 mr-3">
                      <img
                        src={item.product.images?.[0]?.url || 'https://via.placeholder.com/150'}
                        alt={item.product.title}
                        className="w-full h-full object-cover rounded-md"
                      />
                    </div>
                    
                    <div className="flex-1 text-sm">
                      <p className="line-clamp-1">{item.product.title}</p>
                      <p className="text-gray-600">Qty: {item.quantity}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;