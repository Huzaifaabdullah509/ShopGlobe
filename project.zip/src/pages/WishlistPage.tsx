
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '../App';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { Heart, Trash2, ShoppingCart, Plus } from 'lucide-react';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { toast } from 'sonner';

type WishlistItem = {
  id: string;
  product_id: string;
  added_at: string;
  product: {
    id: string;
    title: string;
    slug: string;
    price: number;
    compare_at_price: number | null;
    images: { url: string; alt: string }[];
    inventory_quantity: number;
  };
};

const WishlistPage = () => {
  const { user } = useAuth();
  const { addItem } = useCart();
  const [isRemoving, setIsRemoving] = useState<string | null>(null);
  
  // Fetch wishlist items
  const { data: wishlistItems, isLoading, refetch } = useQuery({
    queryKey: ['wishlist', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      // Get user's default wishlist
      const { data: wishlist, error: wishlistError } = await supabase
        .from('wishlists')
        .select('id')
        .eq('user_id', user.id)
        .eq('name', 'Default')
        .single();
      
      if (wishlistError) {
        // Create default wishlist if it doesn't exist
        if (wishlistError.code === 'PGRST116') {
          const { data: newWishlist } = await supabase
            .from('wishlists')
            .insert({ user_id: user.id, name: 'Default' })
            .select('id')
            .single();
          
          if (newWishlist) {
            return [];
          }
        }
        throw wishlistError;
      }
      
      // Get wishlist items with product details
      const { data, error } = await supabase
        .from('wishlist_items')
        .select(`
          id,
          product_id,
          added_at,
          product:products (
            id,
            title,
            slug,
            price,
            compare_at_price,
            images,
            inventory_quantity
          )
        `)
        .eq('wishlist_id', wishlist.id)
        .order('added_at', { ascending: false });
      
      if (error) throw error;
      return data as WishlistItem[];
    },
    enabled: !!user,
  });
  
  const handleRemoveItem = async (itemId: string) => {
    if (!user) return;
    
    setIsRemoving(itemId);
    
    try {
      const { error } = await supabase
        .from('wishlist_items')
        .delete()
        .eq('id', itemId);
      
      if (error) throw error;
      
      toast.success('Item removed from wishlist');
      refetch();
    } catch (error) {
      console.error('Error removing item from wishlist:', error);
      toast.error('Failed to remove item from wishlist');
    } finally {
      setIsRemoving(null);
    }
  };
  
  const handleAddToCart = async (productId: string) => {
    await addItem(productId);
  };
  
  if (isLoading) {
    return <LoadingSpinner />;
  }
  
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">My Wishlist</h1>
      
      {wishlistItems && wishlistItems.length > 0 ? (
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="divide-y divide-gray-200">
            {wishlistItems.map((item) => (
              <div key={item.id} className="p-4 sm:p-6 flex flex-col sm:flex-row">
                {/* Product Image */}
                <div className="w-full sm:w-24 h-24 mb-4 sm:mb-0 sm:mr-6">
                  <Link to={`/products/${item.product.slug}`}>
                    <img
                      src={item.product.images?.[0]?.url || 'https://via.placeholder.com/150'}
                      alt={item.product.title}
                      className="w-full h-full object-cover rounded-md"
                    />
                  </Link>
                </div>
                
                {/* Product Details */}
                <div className="flex-1">
                  <Link
                    to={`/products/${item.product.slug}`}
                    className="text-lg font-medium text-gray-900 hover:text-blue-600"
                  >
                    {item.product.title}
                  </Link>
                  
                  <div className="mt-1 flex items-center">
                    <span className="font-medium">${item.product.price.toFixed(2)}</span>
                    {item.product.compare_at_price && (
                      <span className="ml-2 text-gray-500 line-through text-sm">
                        ${item.product.compare_at_price.toFixed(2)}
                      </span>
                    )}
                  </div>
                  
                  <div className="mt-2 text-sm text-gray-600">
                    Added on {new Date(item.added_at).toLocaleDateString()}
                  </div>
                  
                  <div className="mt-4 flex flex-wrap gap-2">
                    <button
                      onClick={() => handleAddToCart(item.product_id)}
                      disabled={item.product.inventory_quantity <= 0}
                      className="flex items-center bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-md text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <ShoppingCart size={16} className="mr-1" />
                      Add to Cart
                    </button>
                    
                    <button
                      onClick={() => handleRemoveItem(item.id)}
                      disabled={isRemoving === item.id}
                      className="flex items-center bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1 rounded-md text-sm"
                    >
                      <Trash2 size={16} className="mr-1" />
                      Remove
                    </button>
                  </div>
                </div>
                
                {/* Availability */}
                <div className="mt-4 sm:mt-0 sm:ml-4 text-right">
                  {item.product.inventory_quantity > 0 ? (
                    <span className="text-green-600 text-sm">In Stock</span>
                  ) : (
                    <span className="text-red-600 text-sm">Out of Stock</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <Heart size={48} className="mx-auto text-gray-400 mb-4" />
          <h2 className="text-xl font-medium mb-2">Your wishlist is empty</h2>
          <p className="text-gray-600 mb-6">
            Save items you love to your wishlist and they'll appear here.
          </p>
          <Link
            to="/products"
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md inline-flex items-center"
          >
            <Plus size={16} className="mr-2" />
            Add Products
          </Link>
        </div>
      )}
    </div>
  );
};

export default WishlistPage;