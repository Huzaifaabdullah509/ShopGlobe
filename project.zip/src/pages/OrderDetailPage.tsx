
import { useParams, useNavigate, Link, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '../App';
import { useAuth } from '../contexts/AuthContext';
import { 
  Package, 
  Truck, 
  CreditCard, 
  ChevronLeft, 
  CheckCircle, 
  Clock, 
  AlertCircle 
} from 'lucide-react';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { useEffect } from 'react';
import { toast } from 'sonner';

type Order = {
  id: string;
  created_at: string;
  status: string;
  total_amount: number;
  shipping_address: any;
  billing_address: any;
  shipping_method: string;
  shipping_cost: number;
  tax_amount: number;
  payment_status: string;
  payment_intent_id: string | null;
  notes: string | null;
};

type OrderItem = {
  id: string;
  product_id: string;
  product_snapshot: any;
  quantity: number;
  unit_price: number;
  total_price: number;
};

const OrderDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const showSuccessMessage = searchParams.get('success') === 'true';
  
  useEffect(() => {
    if (showSuccessMessage) {
      toast.success('Order placed successfully!');
      // Remove the success parameter from URL
      navigate(`/orders/${id}`, { replace: true });
    }
  }, [showSuccessMessage, id, navigate]);
  
  // Fetch order details
  const { data: order, isLoading: orderLoading } = useQuery({
    queryKey: ['order', id],
    queryFn: async () => {
      if (!user || !id) return null;
      
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('id', id)
        .eq('user_id', user.id)
        .single();
      
      if (error) throw error;
      return data as Order;
    },
    enabled: !!user && !!id,
  });
  
  // Fetch order items
  const { data: orderItems, isLoading: itemsLoading } = useQuery({
    queryKey: ['order-items', id],
    queryFn: async () => {
      if (!id) return [];
      
      const { data, error } = await supabase
        .from('order_items')
        .select('*')
        .eq('order_id', id);
      
      if (error) throw error;
      return data as OrderItem[];
    },
    enabled: !!id,
  });
  
  const isLoading = orderLoading || itemsLoading;
  
  if (isLoading) {
    return <LoadingSpinner />;
  }
  
  if (!order) {
    return (
      <div className="text-center py-12">
        <AlertCircle size={48} className="mx-auto text-red-500 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Order Not Found</h2>
        <p className="text-gray-600 mb-6">
          The order you're looking for doesn't exist or you don't have permission to view it.
        </p>
        <Link
          to="/orders"
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md inline-block"
        >
          Back to Orders
        </Link>
      </div>
    );
  }
  
  // Get status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'shipped':
        return 'bg-purple-100 text-purple-800';
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Get payment status badge color
  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Get status icon
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered':
        return <CheckCircle size={24} className="text-green-500" />;
      case 'cancelled':
        return <AlertCircle size={24} className="text-red-500" />;
      default:
        return <Clock size={24} className="text-blue-500" />;
    }
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <button
          onClick={() => navigate('/orders')}
          className="flex items-center text-blue-600 hover:text-blue-800"
        >
          <ChevronLeft size={16} className="mr-1" />
          Back to Orders
        </button>
      </div>
      
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Order #{order.id.slice(0, 8)}</h1>
        <div className="flex items-center space-x-3">
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
          </span>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getPaymentStatusColor(order.payment_status)}`}>
            {order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1)}
          </span>
        </div>
      </div>
      
      {/* Order Status Banner */}
      <div className={`mb-8 p-4 rounded-lg flex items-center ${
        order.status === 'delivered' ? 'bg-green-50' : 
        order.status === 'cancelled' ? 'bg-red-50' : 'bg-blue-50'
      }`}>
        {getStatusIcon(order.status)}
        <div className="ml-4">
          <h3 className="font-medium">
            {order.status === 'pending' && 'Your order has been received'}
            {order.status === 'processing' && 'Your order is being processed'}
            {order.status === 'shipped' && 'Your order has been shipped'}
            {order.status === 'delivered' && 'Your order has been delivered'}
            {order.status === 'cancelled' && 'Your order has been cancelled'}
          </h3>
          <p className="text-sm">
            {order.status === 'pending' && 'We\'re preparing your order for processing.'}
            {order.status === 'processing' && 'We\'re getting your items ready to ship.'}
            {order.status === 'shipped' && 'Your order is on its way to you.'}
            {order.status === 'delivered' && 'Your order has been delivered successfully.'}
            {order.status === 'cancelled' && 'Your order has been cancelled.'}
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Order Details */}
        <div className="md:col-span-2 space-y-6">
          {/* Order Items */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <h2 className="font-semibold">Order Items</h2>
            </div>
            
            <div className="divide-y divide-gray-200">
              {orderItems?.map((item) => (
                <div key={item.id} className="p-4 flex">
                  <div className="w-16 h-16 mr-4">
                    <img
                      src={item.product_snapshot.images?.[0]?.url || 'https://via.placeholder.com/150'}
                      alt={item.product_snapshot.title}
                      className="w-full h-full object-cover rounded-md"
                    />
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="font-medium">{item.product_snapshot.title}</h3>
                    <p className="text-sm text-gray-600">Quantity: {item.quantity}</p>
                  </div>
                  
                  <div className="text-right">
                    <p className="font-medium">${item.total_price.toFixed(2)}</p>
                    <p className="text-sm text-gray-600">${item.unit_price.toFixed(2)} each</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Shipping & Billing */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Shipping Information */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-4 border-b border-gray-200 flex items-center">
                <Truck size={18} className="text-gray-500 mr-2" />
                <h2 className="font-semibold">Shipping Information</h2>
              </div>
              
              <div className="p-4">
                <p className="font-medium">{order.shipping_address.fullName}</p>
                <p>{order.shipping_address.addressLine1}</p>
                {order.shipping_address.addressLine2 && <p>{order.shipping_address.addressLine2}</p>}
                <p>{order.shipping_address.city}, {order.shipping_address.state} {order.shipping_address.postalCode}</p>
                <p>{order.shipping_address.country}</p>
                <p>{order.shipping_address.phone}</p>
                
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <p className="text-sm text-gray-600">
                    <span className="font-medium">Shipping Method:</span>{' '}
                    {order.shipping_method === 'standard' ? 'Standard Shipping' : 'Express Shipping'}
                  </p>
                </div>
              </div>
            </div>
            
            {/* Payment Information */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-4 border-b border-gray-200 flex items-center">
                <CreditCard size={18} className="text-gray-500 mr-2" />
                <h2 className="font-semibold">Payment Information</h2>
              </div>
              
              <div className="p-4">
                <p>
                  <span className="font-medium">Payment Method:</span> Credit Card
                </p>
                <p>
                  <span className="font-medium">Payment Status:</span>{' '}
                  <span className={order.payment_status === 'paid' ? 'text-green-600' : 'text-yellow-600'}>
                    {order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1)}
                  </span>
                </p>
                
                {order.billing_address && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <p className="font-medium mb-1">Billing Address:</p>
                    <p>{order.billing_address.fullName}</p>
                    <p>{order.billing_address.addressLine1}</p>
                    {order.billing_address.addressLine2 && <p>{order.billing_address.addressLine2}</p>}
                    <p>{order.billing_address.city}, {order.billing_address.state} {order.billing_address.postalCode}</p>
                    <p>{order.billing_address.country}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* Order Summary */}
        <div className="md:col-span-1">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden sticky top-20">
            <div className="p-4 border-b border-gray-200">
              <h2 className="font-semibold">Order Summary</h2>
            </div>
            
            <div className="p-4">
              <div className="space-y-3 mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span>${(order.total_amount - order.shipping_cost - order.tax_amount).toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  {order.shipping_cost === 0 ? (
                    <span className="text-green-600">Free</span>
                  ) : (
                    <span>${order.shipping_cost.toFixed(2)}</span>
                  )}
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax</span>
                  <span>${order.tax_amount.toFixed(2)}</span>
                </div>
                <div className="border-t border-gray-200 pt-3 flex justify-between font-bold">
                  <span>Total</span>
                  <span>${order.total_amount.toFixed(2)}</span>
                </div>
              </div>
              
              <div className="text-sm text-gray-600">
                <p className="mb-2">
                  <span className="font-medium">Order Date:</span>{' '}
                  {new Date(order.created_at).toLocaleDateString()}
                </p>
                <p>
                  <span className="font-medium">Order ID:</span> {order.id}
                </p>
              </div>
              
              {order.status !== 'cancelled' && order.status !== 'delivered' && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <button
                    className="w-full bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-md"
                  >
                    Cancel Order
                  </button>
                  <p className="text-xs text-gray-500 mt-2 text-center">
                    You can cancel your order only if it hasn't been shipped yet.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetailPage;