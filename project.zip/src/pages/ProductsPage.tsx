
import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '../App';
import { Filter, SlidersHorizontal, X, ChevronDown } from 'lucide-react';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import ProductCard from '../components/products/ProductCard';

type Category = {
  id: string;
  name: string;
  slug: string;
};

type Product = {
  id: string;
  title: string;
  slug: string;
  price: number;
  compare_at_price: number | null;
  images: { url: string; alt: string }[];
  category_id: string;
  inventory_quantity: number;
  tags: string[];
};

const sortOptions = [
  { label: 'Newest', value: 'newest' },
  { label: 'Price: Low to High', value: 'price_asc' },
  { label: 'Price: High to Low', value: 'price_desc' },
  { label: 'Name: A to Z', value: 'name_asc' },
  { label: 'Name: Z to A', value: 'name_desc' },
];

const ProductsPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // Get filter values from URL
  const categorySlug = searchParams.get('category') || '';
  const searchQuery = searchParams.get('search') || '';
  const sortBy = searchParams.get('sort') || 'newest';
  const minPrice = searchParams.get('min_price') || '';
  const maxPrice = searchParams.get('max_price') || '';
  const onSale = searchParams.get('on_sale') === 'true';
  const inStock = searchParams.get('in_stock') === 'true';
  const selectedTags = searchParams.getAll('tag');
  
  // Fetch categories
  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('id, name, slug')
        .order('name');
      
      if (error) throw error;
      return data as Category[];
    }
  });
  
  // Fetch all unique tags
  const { data: allTags, isLoading: tagsLoading } = useQuery({
    queryKey: ['product_tags'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('tags');
      
      if (error) throw error;
      
      // Extract unique tags
      const tagSet = new Set<string>();
      data.forEach(product => {
        if (product.tags) {
          product.tags.forEach((tag: string) => tagSet.add(tag));
        }
      });
      
      return Array.from(tagSet).sort();
    }
  });
  
  // Fetch products with filters
  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ['products', categorySlug, searchQuery, sortBy, minPrice, maxPrice, onSale, inStock, selectedTags],
    queryFn: async () => {
      let query = supabase
        .from('products')
        .select('id, title, slug, price, compare_at_price, images, category_id, inventory_quantity, tags')
        .eq('is_published', true);
      
      // Apply category filter
      if (categorySlug) {
        const { data: categoryData } = await supabase
          .from('categories')
          .select('id')
          .eq('slug', categorySlug)
          .single();
        
        if (categoryData) {
          query = query.eq('category_id', categoryData.id);
        }
      }
      
      // Apply search filter
      if (searchQuery) {
        query = query.ilike('title', `%${searchQuery}%`);
      }
      
      // Apply price filters
      if (minPrice) {
        query = query.gte('price', parseFloat(minPrice));
      }
      
      if (maxPrice) {
        query = query.lte('price', parseFloat(maxPrice));
      }
      
      // Apply sale filter
      if (onSale) {
        query = query.not('compare_at_price', 'is', null);
      }
      
      // Apply stock filter
      if (inStock) {
        query = query.gt('inventory_quantity', 0);
      }
      
      // Apply tag filters
      if (selectedTags.length > 0) {
        query = query.contains('tags', selectedTags);
      }
      
      // Apply sorting
      switch (sortBy) {
        case 'price_asc':
          query = query.order('price', { ascending: true });
          break;
        case 'price_desc':
          query = query.order('price', { ascending: false });
          break;
        case 'name_asc':
          query = query.order('title', { ascending: true });
          break;
        case 'name_desc':
          query = query.order('title', { ascending: false });
          break;
        case 'newest':
        default:
          query = query.order('created_at', { ascending: false });
          break;
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as Product[];
    }
  });
  
  // Update filters
  const updateFilters = (key: string, value: string | string[] | boolean) => {
    const newParams = new URLSearchParams(searchParams.toString());
    
    if (Array.isArray(value)) {
      // Handle array values (tags)
      newParams.delete(key);
      value.forEach(val => newParams.append(key, val));
    } else if (typeof value === 'boolean') {
      // Handle boolean values
      if (value) {
        newParams.set(key, 'true');
      } else {
        newParams.delete(key);
      }
    } else if (value === '') {
      // Remove empty values
      newParams.delete(key);
    } else {
      // Set string values
      newParams.set(key, value);
    }
    
    setSearchParams(newParams);
  };
  
  // Handle tag selection
  const handleTagChange = (tag: string, checked: boolean) => {
    const newTags = [...selectedTags];
    
    if (checked) {
      newTags.push(tag);
    } else {
      const index = newTags.indexOf(tag);
      if (index !== -1) {
        newTags.splice(index, 1);
      }
    }
    
    updateFilters('tag', newTags);
  };
  
  // Clear all filters
  const clearAllFilters = () => {
    const newParams = new URLSearchParams();
    if (searchQuery) {
      newParams.set('search', searchQuery);
    }
    setSearchParams(newParams);
  };
  
  const isLoading = categoriesLoading || tagsLoading || productsLoading;
  const hasActiveFilters = categorySlug || minPrice || maxPrice || onSale || inStock || selectedTags.length > 0;
  
  return (
    <div className="flex flex-col md:flex-row gap-6">
      {/* Mobile Filter Button */}
      <div className="md:hidden flex justify-between items-center mb-4">
        <button
          onClick={() => setIsFilterOpen(!isFilterOpen)}
          className="flex items-center bg-white border border-gray-300 px-4 py-2 rounded-md"
        >
          <Filter size={18} className="mr-2" />
          Filters
        </button>
        
        <div className="relative">
          <select
            value={sortBy}
            onChange={(e) => updateFilters('sort', e.target.value)}
            className="appearance-none bg-white border border-gray-300 px-4 py-2 pr-8 rounded-md"
          >
            {sortOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
          <ChevronDown size={16} className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none" />
        </div>
      </div>
      
      {/* Filters Sidebar */}
      <aside className={`w-full md:w-64 bg-white p-4 rounded-lg shadow-sm ${isFilterOpen ? 'block' : 'hidden'} md:block`}>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Filters</h2>
          <div className="flex items-center">
            {hasActiveFilters && (
              <button
                onClick={clearAllFilters}
                className="text-sm text-blue-600 hover:text-blue-800 mr-2"
              >
                Clear All
              </button>
            )}
            <button
              onClick={() => setIsFilterOpen(false)}
              className="md:hidden"
            >
              <X size={20} />
            </button>
          </div>
        </div>
        
        {/* Categories Filter */}
        <div className="mb-6">
          <h3 className="font-medium mb-2">Categories</h3>
          <div className="space-y-2">
            <div className="flex items-center">
              <input
                type="radio"
                id="category-all"
                name="category"
                checked={!categorySlug}
                onChange={() => updateFilters('category', '')}
                className="mr-2"
              />
              <label htmlFor="category-all">All Categories</label>
            </div>
            {categories?.map((category) => (
              <div key={category.id} className="flex items-center">
                <input
                  type="radio"
                  id={`category-${category.slug}`}
                  name="category"
                  checked={categorySlug === category.slug}
                  onChange={() => updateFilters('category', category.slug)}
                  className="mr-2"
                />
                <label htmlFor={`category-${category.slug}`}>{category.name}</label>
              </div>
            ))}
          </div>
        </div>
        
        {/* Price Filter */}
        <div className="mb-6">
          <h3 className="font-medium mb-2">Price Range</h3>
          <div className="flex items-center">
            <input
              type="number"
              placeholder="Min"
              value={minPrice}
              onChange={(e) => updateFilters('min_price', e.target.value)}
              className="w-1/2 p-2 border border-gray-300 rounded-md mr-2"
            />
            <input
              type="number"
              placeholder="Max"
              value={maxPrice}
              onChange={(e) => updateFilters('max_price', e.target.value)}
              className="w-1/2 p-2 border border-gray-300 rounded-md"
            />
          </div>
        </div>
        
        {/* Availability Filters */}
        <div className="mb-6">
          <h3 className="font-medium mb-2">Availability</h3>
          <div className="space-y-2">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="on-sale"
                checked={onSale}
                onChange={(e) => updateFilters('on_sale', e.target.checked)}
                className="mr-2"
              />
              <label htmlFor="on-sale">On Sale</label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="in-stock"
                checked={inStock}
                onChange={(e) => updateFilters('in_stock', e.target.checked)}
                className="mr-2"
              />
              <label htmlFor="in-stock">In Stock</label>
            </div>
          </div>
        </div>
        
        {/* Tags Filter */}
        {allTags && allTags.length > 0 && (
          <div className="mb-6">
            <h3 className="font-medium mb-2">Tags</h3>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {allTags.map((tag) => (
                <div key={tag} className="flex items-center">
                  <input
                    type="checkbox"
                    id={`tag-${tag}`}
                    checked={selectedTags.includes(tag)}
                    onChange={(e) => handleTagChange(tag, e.target.checked)}
                    className="mr-2"
                  />
                  <label htmlFor={`tag-${tag}`}>{tag}</label>
                </div>
              ))}
            </div>
          </div>
        )}
      </aside>
      
      {/* Products Grid */}
      <div className="flex-1">
        {/* Desktop Sort */}
        <div className="hidden md:flex justify-between items-center mb-6">
          <div>
            {products && (
              <p className="text-gray-600">
                Showing {products.length} {products.length === 1 ? 'product' : 'products'}
              </p>
            )}
          </div>
          
          <div className="flex items-center">
            <span className="mr-2">Sort by:</span>
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => updateFilters('sort', e.target.value)}
                className="appearance-none bg-white border border-gray-300 px-4 py-2 pr-8 rounded-md"
              >
                {sortOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <ChevronDown size={16} className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>
        
        {isLoading ? (
          <LoadingSpinner />
        ) : products && products.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <SlidersHorizontal size={48} className="mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">No products found</h3>
            <p className="text-gray-600 mb-6">
              Try adjusting your filters or search criteria.
            </p>
            <button
              onClick={clearAllFilters}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md"
            >
              Clear All Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductsPage;