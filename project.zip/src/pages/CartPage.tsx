
import { Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { Trash2, ShoppingBag, ArrowRight, Plus, Minus } from 'lucide-react';
import LoadingSpinner from '../components/ui/LoadingSpinner';

const CartPage = () => {
  const { items, isLoading, updateItem, removeItem, clearCart, subtotal, itemCount } = useCart();
  
  if (isLoading) {
    return <LoadingSpinner />;
  }
  
  if (items.length === 0) {
    return (
      <div className="text-center py-12">
        <ShoppingBag size={64} className="mx-auto text-gray-400 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
        <p className="text-gray-600 mb-6">Looks like you haven't added any products to your cart yet.</p>
        <Link
          to="/products"
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md inline-flex items-center"
        >
          Start Shopping
          <ArrowRight size={16} className="ml-2" />
        </Link>
      </div>
    );
  }
  
  // Calculate shipping cost (free over $50)
  const shippingCost = subtotal >= 50 ? 0 : 5.99;
  
  // Calculate tax (assume 8%)
  const taxRate = 0.08;
  const taxAmount = subtotal * taxRate;
  
  // Calculate total
  const total = subtotal + shippingCost + taxAmount;
  
  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">Shopping Cart ({itemCount} {itemCount === 1 ? 'item' : 'items'})</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="divide-y divide-gray-200">
              {items.map((item) => (
                <div key={item.id} className="p-4 sm:p-6 flex flex-col sm:flex-row">
                  {/* Product Image */}
                  <div className="w-full sm:w-24 h-24 mb-4 sm:mb-0 sm:mr-6">
                    <Link to={`/products/${item.product.slug}`}>
                      <img
                        src={item.product.images?.[0]?.url || 'https://via.placeholder.com/150'}
                        alt={item.product.title}
                        className="w-full h-full object-cover rounded-md"
                      />
                    </Link>
                  </div>
                  
                  {/* Product Details */}
                  <div className="flex-1">
                    <Link
                      to={`/products/${item.product.slug}`}
                      className="text-lg font-medium text-gray-900 hover:text-blue-600"
                    >
                      {item.product.title}
                    </Link>
                    
                    <div className="mt-1 flex flex-col sm:flex-row sm:justify-between">
                      <div className="text-gray-600 mb-2 sm:mb-0">
                        ${item.product.price.toFixed(2)} each
                      </div>
                      
                      <div className="flex items-center">
                        {/* Quantity Controls */}
                        <div className="flex items-center border border-gray-300 rounded-md mr-4">
                          <button
                            onClick={() => updateItem(item.product_id, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                            className="px-2 py-1 text-gray-600 hover:bg-gray-100 disabled:opacity-50"
                          >
                            <Minus size={14} />
                          </button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <button
                            onClick={() => updateItem(item.product_id, item.quantity + 1)}
                            className="px-2 py-1 text-gray-600 hover:bg-gray-100"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                        
                        {/* Remove Button */}
                        <button
                          onClick={() => removeItem(item.product_id)}
                          className="text-gray-500 hover:text-red-600"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </div>
                    
                    {/* Item Total */}
                    <div className="mt-2 font-medium">
                      ${(item.product.price * item.quantity).toFixed(2)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Cart Actions */}
            <div className="p-4 sm:p-6 bg-gray-50 flex flex-col sm:flex-row justify-between items-center">
              <div className="mb-4 sm:mb-0">
                <button
                  onClick={clearCart}
                  className="text-red-600 hover:text-red-800 flex items-center"
                >
                  <Trash2 size={16} className="mr-1" />
                  Clear Cart
                </button>
              </div>
              <Link
                to="/products"
                className="text-blue-600 hover:text-blue-800"
              >
                Continue Shopping
              </Link>
            </div>
          </div>
        </div>
        
        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm p-6 sticky top-20">
            <h2 className="text-lg font-bold mb-4">Order Summary</h2>
            
            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Shipping</span>
                {shippingCost === 0 ? (
                  <span className="text-green-600">Free</span>
                ) : (
                  <span>${shippingCost.toFixed(2)}</span>
                )}
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tax (8%)</span>
                <span>${taxAmount.toFixed(2)}</span>
              </div>
              <div className="border-t border-gray-200 pt-3 flex justify-between font-bold">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>
            
            {/* Shipping Notice */}
            {subtotal < 50 && (
              <div className="bg-blue-50 text-blue-800 p-3 rounded-md text-sm mb-6">
                Add ${(50 - subtotal).toFixed(2)} more to qualify for free shipping!
              </div>
            )}
            
            <Link
              to="/checkout"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-md flex items-center justify-center"
            >
              Proceed to Checkout
              <ArrowRight size={16} className="ml-2" />
            </Link>
            
            {/* Payment Methods */}
            <div className="mt-6">
              <div className="text-sm text-gray-600 mb-2">We Accept:</div>
              <div className="flex space-x-2">
                <div className="w-10 h-6 bg-gray-200 rounded"></div>
                <div className="w-10 h-6 bg-gray-200 rounded"></div>
                <div className="w-10 h-6 bg-gray-200 rounded"></div>
                <div className="w-10 h-6 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;