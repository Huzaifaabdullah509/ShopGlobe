
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '../../App';
import { useAuth } from '../../contexts/AuthContext';
import { 
  BarChart as BarChartIcon, 
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
  Calendar,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Package,
  Users,
  ShoppingBag
} from 'lucide-react';
import LoadingSpinner from '../../components/ui/LoadingSpinner';

const AnalyticsPage = () => {
  const { profile } = useAuth();
  const [dateRange, setDateRange] = useState('30days'); // '7days', '30days', '90days', 'year'
  
  // Fetch analytics data
  const { data, isLoading } = useQuery({
    queryKey: ['analytics', dateRange],
    queryFn: async () => {
      // Get date range
      const now = new Date();
      let startDate = new Date();
      
      switch (dateRange) {
        case '7days':
          startDate.setDate(now.getDate() - 7);
          break;
        case '30days':
          startDate.setDate(now.getDate() - 30);
          break;
        case '90days':
          startDate.setDate(now.getDate() - 90);
          break;
        case 'year':
          startDate.setFullYear(now.getFullYear() - 1);
          break;
      }
      
      // Format dates for query
      const startDateStr = startDate.toISOString();
      const endDateStr = now.toISOString();
      
      // Get orders in date range
      const { data: orders, error: ordersError } = await supabase
        .from('orders')
        .select('id, created_at, total_amount, status, payment_status')
        .gte('created_at', startDateStr)
        .lte('created_at', endDateStr)
        .order('created_at');
      
      if (ordersError) throw ordersError;
      
      // Get new customers in date range
      const { data: newCustomers, error: customersError } = await supabase
        .from('users')
        .select('id, created_at')
        .eq('role', 'customer')
        .gte('created_at', startDateStr)
        .lte('created_at', endDateStr);
      
      if (customersError) throw customersError;
      
      // Get top products
      const { data: orderItems, error: itemsError } = await supabase
        .from('order_items')
        .select(`
          product_id,
          product_snapshot,
          quantity
        `)
        .in('order_id', orders.map(order => order.id));
      
      if (itemsError) throw itemsError;
      
      // Calculate top products
      const productSales: Record<string, { name: string, quantity: number, revenue: number }> = {};
      
      orderItems.forEach(item => {
        const productId = item.product_id;
        const productName = item.product_snapshot.title;
        const quantity = item.quantity;
        const revenue = item.product_snapshot.price * quantity;
        
        if (!productSales[productId]) {
          productSales[productId] = { name: productName, quantity: 0, revenue: 0 };
        }
        
        productSales[productId].quantity += quantity;
        productSales[productId].revenue += revenue;
      });
      
      const topProducts = Object.values(productSales)
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 5);
      
      // Calculate revenue by day/week/month
      const revenueByPeriod: Record<string, number> = {};
      const completedOrders = orders.filter(order => order.payment_status === 'paid');
      
      if (dateRange === '7days' || dateRange === '30days') {
        // Group by day
        completedOrders.forEach(order => {
          const date = new Date(order.created_at).toISOString().split('T')[0];
          revenueByPeriod[date] = (revenueByPeriod[date] || 0) + order.total_amount;
        });
      } else {
        // Group by month
        completedOrders.forEach(order => {
          const date = new Date(order.created_at);
          const monthYear = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
          revenueByPeriod[monthYear] = (revenueByPeriod[monthYear] || 0) + order.total_amount;
        });
      }
      
      // Calculate total revenue
      const totalRevenue = completedOrders.reduce((sum, order) => sum + order.total_amount, 0);
      
      // Calculate order status breakdown
      const orderStatusCounts: Record<string, number> = {};
      orders.forEach(order => {
        orderStatusCounts[order.status] = (orderStatusCounts[order.status] || 0) + 1;
      });
      
      return {
        totalRevenue,
        totalOrders: orders.length,
        newCustomers: newCustomers.length,
        averageOrderValue: orders.length > 0 ? totalRevenue / orders.length : 0,
        topProducts,
        revenueByPeriod,
        orderStatusCounts
      };
    }
  });
  
  if (isLoading) {
    return <LoadingSpinner />;
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h1 className="text-2xl font-bold">Analytics</h1>
        
        <div className="flex items-center">
          <Calendar size={18} className="text-gray-400 mr-2" />
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="7days">Last 7 Days</option>
            <option value="30days">Last 30 Days</option>
            <option value="90days">Last 90 Days</option>
            <option value="year">Last Year</option>
          </select>
        </div>
      </div>
      
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Revenue</p>
              <h3 className="text-2xl font-bold">${data?.totalRevenue.toFixed(2)}</h3>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <DollarSign size={20} className="text-green-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <span className="text-green-600 flex items-center font-medium">
              <TrendingUp size={16} className="mr-1" />
              12%
            </span>
            <span className="text-gray-500 ml-2">vs. previous period</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Orders</p>
              <h3 className="text-2xl font-bold">{data?.totalOrders}</h3>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <Package size={20} className="text-blue-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <span className="text-green-600 flex items-center font-medium">
              <TrendingUp size={16} className="mr-1" />
              8%
            </span>
            <span className="text-gray-500 ml-2">vs. previous period</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">New Customers</p>
              <h3 className="text-2xl font-bold">{data?.newCustomers}</h3>
            </div>
            <div className="bg-purple-100 p-3 rounded-full">
              <Users size={20} className="text-purple-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <span className="text-red-600 flex items-center font-medium">
              <TrendingDown size={16} className="mr-1" />
              3%
            </span>
            <span className="text-gray-500 ml-2">vs. previous period</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">Avg. Order Value</p>
              <h3 className="text-2xl font-bold">${data?.averageOrderValue.toFixed(2)}</h3>
            </div>
            <div className="bg-orange-100 p-3 rounded-full">
              <ShoppingBag size={20} className="text-orange-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <span className="text-green-600 flex items-center font-medium">
              <TrendingUp size={16} className="mr-1" />
              5%
            </span>
            <span className="text-gray-500 ml-2">vs. previous period</span>
          </div>
        </div>
      </div>
      
      {/* Revenue Chart */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-semibold flex items-center">
            <LineChartIcon size={18} className="text-gray-500 mr-2" />
            Revenue Over Time
          </h2>
        </div>
        
        <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
          <div className="text-center">
            <LineChartIcon size={48} className="mx-auto text-gray-400 mb-2" />
            <p className="text-gray-500">Revenue chart will be displayed here</p>
            <p className="text-sm text-gray-400">
              {Object.keys(data?.revenueByPeriod || {}).length} data points available
            </p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Products */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold flex items-center">
              <BarChartIcon size={18} className="text-gray-500 mr-2" />
              Top Selling Products
            </h2>
          </div>
          
          {data?.topProducts && data.topProducts.length > 0 ? (
            <div className="space-y-4">
              {data.topProducts.map((product, index) => (
                <div key={index} className="flex items-center">
                  <div className="w-8 text-gray-500 font-medium">#{index + 1}</div>
                  <div className="flex-1">
                    <div className="font-medium">{product.name}</div>
                    <div className="text-sm text-gray-500">{product.quantity} sold</div>
                  </div>
                  <div className="font-medium">${product.revenue.toFixed(2)}</div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <BarChartIcon size={36} className="mx-auto text-gray-400 mb-2" />
              <p className="text-gray-500">No product sales data available</p>
            </div>
          )}
        </div>
        
        {/* Order Status */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold flex items-center">
              <PieChartIcon size={18} className="text-gray-500 mr-2" />
              Order Status Breakdown
            </h2>
          </div>
          
          {data?.orderStatusCounts && Object.keys(data.orderStatusCounts).length > 0 ? (
            <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
              <div className="text-center">
                <PieChartIcon size={48} className="mx-auto text-gray-400 mb-2" />
                <p className="text-gray-500">Order status chart will be displayed here</p>
                <div className="flex flex-wrap justify-center gap-2 mt-4">
                  {Object.entries(data.orderStatusCounts).map(([status, count]) => (
                    <div key={status} className="px-3 py-1 rounded-full text-xs font-medium bg-gray-100">
                      {status}: {count}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <PieChartIcon size={36} className="mx-auto text-gray-400 mb-2" />
              <p className="text-gray-500">No order status data available</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;