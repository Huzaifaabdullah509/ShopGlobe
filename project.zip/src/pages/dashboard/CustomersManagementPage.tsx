
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '../../App';
import { useAuth } from '../../contexts/AuthContext';
import { 
  Search, 
  ChevronLeft, 
  ChevronRight,
  AlertCircle,
  Mail,
  Phone,
  MapPin,
  Package,
  ShoppingBag
} from 'lucide-react';
import LoadingSpinner from '../../components/ui/LoadingSpinner';

type Customer = {
  id: string;
  email: string;
  full_name: string;
  role: string;
  created_at: string;
  avatar_url: string | null;
  phone: string | null;
  address: string | null;
  orders_count: number;
  total_spent: number;
};

const CustomersManagementPage = () => {
  const { profile } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const customersPerPage = 10;
  
  // Check if user is admin
  const isAdmin = profile?.role === 'admin';
  
  // Fetch customers with pagination
  const { data, isLoading } = useQuery({
    queryKey: ['admin-customers', currentPage, searchQuery],
    queryFn: async () => {
      if (!isAdmin) {
        throw new Error('Unauthorized');
      }
      
      let query = supabase
        .from('users')
        .select('id, email, full_name, role, created_at, avatar_url, phone, address')
        .eq('role', 'customer');
      
      // Apply search filter
      if (searchQuery) {
        query = query.or(`email.ilike.%${searchQuery}%,full_name.ilike.%${searchQuery}%`);
      }
      
      // Get total count
      const { count } = await query.select('id', { count: 'exact', head: true });
      
      // Apply pagination
      const from = (currentPage - 1) * customersPerPage;
      const to = from + customersPerPage - 1;
      
      const { data: customers, error } = await query
        .order('created_at', { ascending: false })
        .range(from, to);
      
      if (error) throw error;
      
      // Get order counts and total spent for each customer
      const customersWithStats = await Promise.all(
        customers.map(async (customer) => {
          // Get order count
          const { count: ordersCount } = await supabase
            .from('orders')
            .select('id', { count: 'exact', head: true })
            .eq('user_id', customer.id);
          
          // Get total spent
          const { data: orders } = await supabase
            .from('orders')
            .select('total_amount')
            .eq('user_id', customer.id)
            .eq('payment_status', 'paid');
          
          const totalSpent = orders?.reduce((sum, order) => sum + order.total_amount, 0) || 0;
          
          return {
            ...customer,
            orders_count: ordersCount || 0,
            total_spent: totalSpent
          };
        })
      );
      
      return {
        customers: customersWithStats as Customer[],
        totalCount: count || 0,
        totalPages: Math.ceil((count || 0) / customersPerPage)
      };
    },
    enabled: isAdmin
  });
  
  if (!isAdmin) {
    return (
      <div className="text-center py-12">
        <AlertCircle size={48} className="mx-auto text-red-500 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
        <p className="text-gray-600 mb-6">
          You don't have permission to view this page.
        </p>
      </div>
    );
  }
  
  if (isLoading) {
    return <LoadingSpinner />;
  }
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Customers</h1>
      
      {/* Search */}
      <div className="bg-white rounded-lg shadow-sm p-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search customers by name or email..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            className="pl-10 w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>
      
      {/* Customers Table */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contact
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Joined
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Orders
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total Spent
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {data?.customers.map((customer) => (
                <tr key={customer.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 flex-shrink-0">
                        {customer.avatar_url ? (
                          <img
                            className="h-10 w-10 rounded-full object-cover"
                            src={customer.avatar_url}
                            alt={customer.full_name}
                          />
                        ) : (
                          <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 font-medium">
                            {customer.full_name ? customer.full_name[0].toUpperCase() : 'U'}
                          </div>
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{customer.full_name || 'Unnamed'}</div>
                        <div className="text-sm text-gray-500">{customer.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">
                      {customer.phone && (
                        <div className="flex items-center mb-1">
                          <Phone size={14} className="mr-1" />
                          {customer.phone}
                        </div>
                      )}
                      {customer.address && (
                        <div className="flex items-center">
                          <MapPin size={14} className="mr-1" />
                          {customer.address}
                        </div>
                      )}
                      {!customer.phone && !customer.address && (
                        <div className="flex items-center">
                          <Mail size={14} className="mr-1" />
                          {customer.email}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(customer.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-900">
                      <Package size={16} className="text-gray-400 mr-2" />
                      {customer.orders_count}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm font-medium text-gray-900">
                      <ShoppingBag size={16} className="text-gray-400 mr-2" />
                      ${customer.total_spent.toFixed(2)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button
                      onClick={() => window.location.href = `/dashboard/customers/${customer.id}`}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
              
              {(!data?.customers || data.customers.length === 0) && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center">
                    <AlertCircle size={48} className="mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-500 text-lg mb-1">No customers found</p>
                    <p className="text-gray-400 text-sm">
                      {searchQuery ? 'Try adjusting your search' : 'No customers have registered yet'}
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        {data && data.totalPages > 1 && (
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
            <div className="text-sm text-gray-500">
              Showing {(currentPage - 1) * customersPerPage + 1} to {Math.min(currentPage * customersPerPage, data.totalCount)} of {data.totalCount} customers
            </div>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="p-2 rounded-md border border-gray-300 bg-white text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ChevronLeft size={16} />
              </button>
              
              {Array.from({ length: data.totalPages }, (_, i) => i + 1)
                .filter(page => {
                  // Show current page, first page, last page, and pages around current page
                  return (
                    page === 1 ||
                    page === data.totalPages ||
                    (page >= currentPage - 1 && page <= currentPage + 1)
                  );
                })
                .map((page, index, array) => {
                  // Add ellipsis
                  const showEllipsisBefore = index > 0 && array[index - 1] !== page - 1;
                  const showEllipsisAfter = index < array.length - 1 && array[index + 1] !== page + 1;
                  
                  return (
                    <div key={page} className="flex items-center">
                      {showEllipsisBefore && (
                        <span className="px-3 py-2 text-gray-500">...</span>
                      )}
                      
                      <button
                        onClick={() => setCurrentPage(page)}
                        className={`px-3 py-2 rounded-md ${
                          currentPage === page
                            ? 'bg-blue-600 text-white'
                            : 'border border-gray-300 bg-white text-gray-500 hover:bg-gray-50'
                        }`}
                      >
                        {page}
                      </button>
                      
                      {showEllipsisAfter && (
                        <span className="px-3 py-2 text-gray-500">...</span>
                      )}
                    </div>
                  );
                })}
              
              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, data.totalPages))}
                disabled={currentPage === data.totalPages}
                className="p-2 rounded-md border border-gray-300 bg-white text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomersManagementPage;