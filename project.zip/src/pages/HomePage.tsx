
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../App';
import { useQuery } from '@tanstack/react-query';
import { ChevronRight, ArrowRight } from 'lucide-react';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import ProductCard from '../components/products/ProductCard';

type Category = {
  id: string;
  name: string;
  slug: string;
  image_url: string;
};

type Product = {
  id: string;
  title: string;
  slug: string;
  price: number;
  compare_at_price: number | null;
  images: { url: string; alt: string }[];
  category_id: string;
};

const HomePage = () => {
  // Fetch featured categories
  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('id, name, slug, image_url')
        .order('name');
      
      if (error) throw error;
      return data as Category[];
    }
  });

  // Fetch featured products
  const { data: featuredProducts, isLoading: productsLoading } = useQuery({
    queryKey: ['featuredProducts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('id, title, slug, price, compare_at_price, images, category_id')
        .order('created_at', { ascending: false })
        .limit(8);
      
      if (error) throw error;
      return data as Product[];
    }
  });

  // Hero banner slides
  const heroSlides = [
    {
      id: 1,
      title: 'Summer Collection 2025',
      description: 'Discover the latest trends for the summer season',
      image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?ixlib=rb-4.0.3',
      link: '/products?category=fashion'
    },
    {
      id: 2,
      title: 'Tech Gadgets Sale',
      description: 'Up to 40% off on the latest electronics',
      image: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?ixlib=rb-4.0.3',
      link: '/products?category=electronics'
    },
    {
      id: 3,
      title: 'Home Essentials',
      description: 'Transform your living space with our home collection',
      image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?ixlib=rb-4.0.3',
      link: '/products?category=home-kitchen'
    }
  ];

  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [heroSlides.length]);

  const isLoading = categoriesLoading || productsLoading;

  if (isLoading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="space-y-12">
      {/* Hero Banner */}
      <section className="relative h-96 overflow-hidden rounded-xl">
        {heroSlides.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url(${slide.image})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          >
            <div className="flex flex-col justify-center h-full max-w-xl px-8">
              <h1 className="text-4xl font-bold text-white mb-4">{slide.title}</h1>
              <p className="text-xl text-white mb-6">{slide.description}</p>
              <Link
                to={slide.link}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md inline-flex items-center w-fit"
              >
                Shop Now
                <ChevronRight size={20} className="ml-2" />
              </Link>
            </div>
          </div>
        ))}

        {/* Slide Indicators */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {heroSlides.map((_, index) => (
            <button
              key={index}
              className={`w-3 h-3 rounded-full ${
                index === currentSlide ? 'bg-white' : 'bg-white/50'
              }`}
              onClick={() => setCurrentSlide(index)}
            />
          ))}
        </div>
      </section>

      {/* Featured Categories */}
      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Shop by Category</h2>
          <Link
            to="/products"
            className="text-blue-600 hover:text-blue-800 flex items-center"
          >
            View All
            <ChevronRight size={16} className="ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {categories?.map((category) => (
            <Link
              key={category.id}
              to={`/products?category=${category.slug}`}
              className="group"
            >
              <div className="relative h-40 rounded-lg overflow-hidden">
                <div
                  className="absolute inset-0 bg-cover bg-center group-hover:scale-105 transition-transform duration-300"
                  style={{ backgroundImage: `url(${category.image_url})` }}
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 group-hover:bg-opacity-30 transition-colors duration-300" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <h3 className="text-white text-lg font-semibold">{category.name}</h3>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Featured Products</h2>
          <Link
            to="/products"
            className="text-blue-600 hover:text-blue-800 flex items-center"
          >
            View All
            <ChevronRight size={16} className="ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {featuredProducts?.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Promotional Banners */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="relative h-64 rounded-lg overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url(https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3)`
            }}
          />
          <div className="absolute inset-0 flex flex-col justify-center p-8">
            <h3 className="text-2xl font-bold text-white mb-2">New Arrivals</h3>
            <p className="text-white mb-4">Check out the latest additions to our store</p>
            <Link
              to="/products?sort=newest"
              className="bg-white text-gray-900 hover:bg-gray-100 px-4 py-2 rounded-md inline-flex items-center w-fit"
            >
              Shop New
              <ArrowRight size={16} className="ml-2" />
            </Link>
          </div>
        </div>
        <div className="relative h-64 rounded-lg overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url(https://images.unsplash.com/photo-1607082349566-187342175e2f?ixlib=rb-4.0.3)`
            }}
          />
          <div className="absolute inset-0 flex flex-col justify-center p-8">
            <h3 className="text-2xl font-bold text-white mb-2">Special Offers</h3>
            <p className="text-white mb-4">Limited-time deals on popular products</p>
            <Link
              to="/products?on_sale=true"
              className="bg-white text-gray-900 hover:bg-gray-100 px-4 py-2 rounded-md inline-flex items-center w-fit"
            >
              View Deals
              <ArrowRight size={16} className="ml-2" />
            </Link>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="bg-blue-50 rounded-xl p-8 text-center">
        <h2 className="text-2xl font-bold mb-2">Subscribe to our Newsletter</h2>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          Stay updated with our latest products, exclusive offers, and shopping tips.
        </p>
        <form className="flex flex-col sm:flex-row max-w-md mx-auto">
          <input
            type="email"
            placeholder="Your email address"
            className="flex-grow px-4 py-3 rounded-l-md sm:rounded-r-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent mb-2 sm:mb-0"
            required
          />
          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md sm:rounded-l-none"
          >
            Subscribe
          </button>
        </form>
      </section>
    </div>
  );
};

export default HomePage;