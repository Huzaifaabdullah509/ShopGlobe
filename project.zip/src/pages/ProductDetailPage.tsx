
import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '../App';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { 
  Minus, 
  Plus, 
  Heart, 
  Share, 
  Star, 
  ChevronRight,
  ShoppingCart,
  Check,
  Truck,
  RefreshCw,
  Shield
} from 'lucide-react';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import ProductCard from '../components/products/ProductCard';
import { toast } from 'sonner';

type Product = {
  id: string;
  title: string;
  slug: string;
  description: string;
  price: number;
  compare_at_price: number | null;
  inventory_quantity: number;
  images: { url: string; alt: string }[];
  category: {
    id: string;
    name: string;
    slug: string;
  };
  tags: string[];
};

type Review = {
  id: string;
  user_id: string;
  product_id: string;
  rating: number;
  title: string;
  comment: string;
  is_verified_purchase: boolean;
  helpful_votes: number;
  unhelpful_votes: number;
  created_at: string;
  user: {
    full_name: string;
  };
};

const ProductDetailPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const { addItem } = useCart();
  const { user } = useAuth();
  
  // Fetch product details
  const { data: product, isLoading: productLoading } = useQuery({
    queryKey: ['product', slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select(`
          id, 
          title, 
          slug, 
          description, 
          price, 
          compare_at_price, 
          inventory_quantity, 
          images, 
          tags,
          category:categories (id, name, slug)
        `)
        .eq('slug', slug)
        .eq('is_published', true)
        .single();
      
      if (error) throw error;
      return data as Product;
    },
    enabled: !!slug
  });
  
  // Fetch product reviews
  const { data: reviews, isLoading: reviewsLoading } = useQuery({
    queryKey: ['product-reviews', slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('reviews')
        .select(`
          id, 
          user_id, 
          product_id, 
          rating, 
          title, 
          comment, 
          is_verified_purchase, 
          helpful_votes, 
          unhelpful_votes, 
          created_at,
          user:users (full_name)
        `)
        .eq('product_id', product?.id)
        .eq('is_approved', true)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as Review[];
    },
    enabled: !!product?.id
  });
  
  // Fetch related products
  const { data: relatedProducts, isLoading: relatedLoading } = useQuery({
    queryKey: ['related-products', product?.category?.id, product?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('id, title, slug, price, compare_at_price, images')
        .eq('category_id', product?.category?.id)
        .neq('id', product?.id)
        .eq('is_published', true)
        .limit(4);
      
      if (error) throw error;
      return data;
    },
    enabled: !!product?.category?.id && !!product?.id
  });
  
  const isLoading = productLoading || reviewsLoading || relatedLoading;
  
  if (isLoading) {
    return <LoadingSpinner />;
  }
  
  if (!product) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
        <p className="mb-6">The product you're looking for doesn't exist or has been removed.</p>
        <Link to="/products" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md">
          Browse Products
        </Link>
      </div>
    );
  }
  
  const {
    title,
    description,
    price,
    compare_at_price,
    inventory_quantity,
    images,
    category,
    tags
  } = product;
  
  const inStock = inventory_quantity > 0;
  const discountPercentage = compare_at_price
    ? Math.round(((compare_at_price - price) / compare_at_price) * 100)
    : null;
  
  // Calculate average rating
  const averageRating = reviews && reviews.length > 0
    ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
    : 0;
  
  const handleQuantityChange = (value: number) => {
    const newQuantity = Math.max(1, Math.min(value, inventory_quantity || 10));
    setQuantity(newQuantity);
  };
  
  const handleAddToCart = () => {
    addItem(product.id, quantity);
  };
  
  const handleAddToWishlist = () => {
    toast.info('Feature coming soon: Add to wishlist');
  };
  
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.title,
        url: window.location.href,
      }).catch(err => {
        console.error('Error sharing:', err);
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success('Link copied to clipboard');
    }
  };
  
  return (
    <div className="space-y-12">
      {/* Breadcrumbs */}
      <nav className="flex text-sm">
        <Link to="/" className="text-gray-500 hover:text-blue-600">Home</Link>
        <ChevronRight size={16} className="mx-2 text-gray-400" />
        <Link to="/products" className="text-gray-500 hover:text-blue-600">Products</Link>
        {category && (
          <>
            <ChevronRight size={16} className="mx-2 text-gray-400" />
            <Link 
              to={`/products?category=${category.slug}`} 
              className="text-gray-500 hover:text-blue-600"
            >
              {category.name}
            </Link>
          </>
        )}
        <ChevronRight size={16} className="mx-2 text-gray-400" />
        <span className="text-gray-900 font-medium">{title}</span>
      </nav>
      
      {/* Product Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="bg-white rounded-lg overflow-hidden h-80 md:h-96">
            {images && images.length > 0 ? (
              <img
                src={images[selectedImage].url}
                alt={images[selectedImage].alt || title}
                className="w-full h-full object-contain"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gray-100">
                <span className="text-gray-400">No image available</span>
              </div>
            )}
          </div>
          
          {images && images.length > 1 && (
            <div className="flex space-x-2 overflow-x-auto pb-2">
              {images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`w-20 h-20 rounded-md overflow-hidden border-2 ${
                    selectedImage === index ? 'border-blue-500' : 'border-transparent'
                  }`}
                >
                  <img
                    src={image.url}
                    alt={image.alt || `${title} - Image ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{title}</h1>
            
            {/* Ratings */}
            {reviews && (
              <div className="flex items-center mb-4">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      size={18}
                      className={`${
                        star <= Math.round(averageRating)
                          ? 'text-yellow-400 fill-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="ml-2 text-sm text-gray-600">
                  {averageRating.toFixed(1)} ({reviews.length} {reviews.length === 1 ? 'review' : 'reviews'})
                </span>
              </div>
            )}
            
            {/* Price */}
            <div className="flex items-center mb-4">
              <span className="text-2xl font-bold text-gray-900">${price.toFixed(2)}</span>
              {compare_at_price && (
                <>
                  <span className="ml-2 text-gray-500 line-through">${compare_at_price.toFixed(2)}</span>
                  <span className="ml-2 bg-red-100 text-red-700 px-2 py-0.5 rounded text-sm font-medium">
                    Save {discountPercentage}%
                  </span>
                </>
              )}
            </div>
            
            {/* Availability */}
            <div className="mb-4">
              {inStock ? (
                <div className="flex items-center text-green-600">
                  <Check size={18} className="mr-1" />
                  <span>In Stock ({inventory_quantity} available)</span>
                </div>
              ) : (
                <div className="text-red-600">Out of Stock</div>
              )}
            </div>
          </div>
          
          {/* Description */}
          <div>
            <h3 className="text-lg font-medium mb-2">Description</h3>
            <div className="text-gray-700 prose max-w-none">
              {description ? (
                <p>{description}</p>
              ) : (
                <p>No description available for this product.</p>
              )}
            </div>
          </div>
          
          {/* Tags */}
          {tags && tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {tags.map((tag) => (
                <Link
                  key={tag}
                  to={`/products?tag=${tag}`}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-1 rounded-full text-sm"
                >
                  {tag}
                </Link>
              ))}
            </div>
          )}
          
          {/* Add to Cart */}
          <div className="pt-4 border-t border-gray-200">
            <div className="flex items-center mb-4">
              <div className="flex items-center border border-gray-300 rounded-md mr-4">
                <button
                  onClick={() => handleQuantityChange(quantity - 1)}
                  disabled={quantity <= 1}
                  className="px-3 py-2 text-gray-600 hover:bg-gray-100 disabled:opacity-50"
                >
                  <Minus size={16} />
                </button>
                <input
                  type="number"
                  min="1"
                  max={inventory_quantity || 10}
                  value={quantity}
                  onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                  className="w-12 text-center border-x border-gray-300 py-2 focus:outline-none"
                />
                <button
                  onClick={() => handleQuantityChange(quantity + 1)}
                  disabled={quantity >= (inventory_quantity || 10)}
                  className="px-3 py-2 text-gray-600 hover:bg-gray-100 disabled:opacity-50"
                >
                  <Plus size={16} />
                </button>
              </div>
              
              <button
                onClick={handleAddToCart}
                disabled={!inStock}
                className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white py-3 px-6 rounded-md flex items-center justify-center"
              >
                <ShoppingCart size={18} className="mr-2" />
                Add to Cart
              </button>
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={handleAddToWishlist}
                className="flex items-center text-gray-700 hover:text-blue-600"
              >
                <Heart size={18} className="mr-1" />
                <span>Add to Wishlist</span>
              </button>
              <button
                onClick={handleShare}
                className="flex items-center text-gray-700 hover:text-blue-600"
              >
                <Share size={18} className="mr-1" />
                <span>Share</span>
              </button>
            </div>
          </div>
          
          {/* Shipping & Returns */}
          <div className="pt-4 border-t border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start">
                <Truck size={20} className="text-gray-600 mr-2 mt-0.5" />
                <div>
                  <h4 className="font-medium">Free Shipping</h4>
                  <p className="text-sm text-gray-600">On orders over $50</p>
                </div>
              </div>
              <div className="flex items-start">
                <RefreshCw size={20} className="text-gray-600 mr-2 mt-0.5" />
                <div>
                  <h4 className="font-medium">Easy Returns</h4>
                  <p className="text-sm text-gray-600">30 day return policy</p>
                </div>
              </div>
              <div className="flex items-start">
                <Shield size={20} className="text-gray-600 mr-2 mt-0.5" />
                <div>
                  <h4 className="font-medium">Secure Payments</h4>
                  <p className="text-sm text-gray-600">Encrypted payment processing</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Reviews Section */}
      <section className="border-t border-gray-200 pt-8">
        <h2 className="text-2xl font-bold mb-6">Customer Reviews</h2>
        
        {reviews && reviews.length > 0 ? (
          <div className="space-y-6">
            {/* Review Summary */}
            <div className="flex flex-col md:flex-row md:items-center mb-6">
              <div className="flex items-center mb-4 md:mb-0 md:mr-8">
                <div className="text-4xl font-bold text-gray-900 mr-4">{averageRating.toFixed(1)}</div>
                <div>
                  <div className="flex mb-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        size={20}
                        className={`${
                          star <= Math.round(averageRating)
                            ? 'text-yellow-400 fill-yellow-400'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  <div className="text-sm text-gray-600">
                    Based on {reviews.length} {reviews.length === 1 ? 'review' : 'reviews'}
                  </div>
                </div>
              </div>
              
              {user ? (
                <Link
                  to={`/products/${slug}/review`}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md inline-block"
                >
                  Write a Review
                </Link>
              ) : (
                <Link
                  to={`/login?redirect=/products/${slug}/review`}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md inline-block"
                >
                  Sign in to Write a Review
                </Link>
              )}
            </div>
            
            {/* Review List */}
            <div className="space-y-6">
              {reviews.map((review) => (
                <div key={review.id} className="border-b border-gray-200 pb-6">
                  <div className="flex justify-between mb-2">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          size={16}
                          className={`${
                            star <= review.rating
                              ? 'text-yellow-400 fill-yellow-400'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <div className="text-sm text-gray-600">
                      {new Date(review.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  
                  <h4 className="font-medium mb-1">{review.title || 'Review'}</h4>
                  <p className="text-gray-700 mb-2">{review.comment}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-600">
                      By {review.user?.full_name || 'Anonymous'}
                      {review.is_verified_purchase && (
                        <span className="ml-2 text-green-600 text-xs font-medium">
                          Verified Purchase
                        </span>
                      )}
                    </div>
                    
                    <div className="text-sm">
                      <span className="text-gray-600 mr-4">
                        {review.helpful_votes} {review.helpful_votes === 1 ? 'person' : 'people'} found this helpful
                      </span>
                      <button className="text-blue-600 hover:text-blue-800">
                        Helpful
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-8 bg-gray-50 rounded-lg">
            <h3 className="text-lg font-medium text-gray-900 mb-2">No reviews yet</h3>
            <p className="text-gray-600 mb-4">Be the first to review this product</p>
            
            {user ? (
              <Link
                to={`/products/${slug}/review`}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md inline-block"
              >
                Write a Review
              </Link>
            ) : (
              <Link
                to={`/login?redirect=/products/${slug}/review`}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md inline-block"
              >
                Sign in to Write a Review
              </Link>
            )}
          </div>
        )}
      </section>
      
      {/* Related Products */}
      {relatedProducts && relatedProducts.length > 0 && (
        <section className="border-t border-gray-200 pt-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Related Products</h2>
            <Link
              to={`/products?category=${category?.slug}`}
              className="text-blue-600 hover:text-blue-800 flex items-center"
            >
              View All
              <ChevronRight size={16} className="ml-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {relatedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

export default ProductDetailPage;