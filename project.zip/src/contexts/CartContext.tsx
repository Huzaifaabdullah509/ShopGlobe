
import { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../App';
import { useAuth } from './AuthContext';
import { toast } from 'sonner';

export type CartItem = {
  id: string;
  product_id: string;
  quantity: number;
  product: {
    id: string;
    title: string;
    price: number;
    images: { url: string; alt: string }[];
    slug: string;
  };
};

type CartContextType = {
  items: CartItem[];
  isLoading: boolean;
  cartId: string | null;
  addItem: (productId: string, quantity?: number) => Promise<void>;
  updateItem: (productId: string, quantity: number) => Promise<void>;
  removeItem: (productId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  itemCount: number;
  subtotal: number;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider = ({ children }: { children: React.ReactNode }) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const [cartId, setCartId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();
  
  // Calculate derived values
  const itemCount = items.reduce((total, item) => total + item.quantity, 0);
  const subtotal = items.reduce(
    (total, item) => total + item.quantity * item.product.price,
    0
  );

  // Initialize cart
  useEffect(() => {
    const initializeCart = async () => {
      setIsLoading(true);
      
      // Check for existing cart in localStorage
      const sessionId = localStorage.getItem('cartSessionId');
      
      if (user) {
        // User is logged in, check for their cart
        const { data: userCart } = await supabase
          .from('carts')
          .select('id')
          .eq('user_id', user.id)
          .single();
        
        if (userCart) {
          // User has a cart
          setCartId(userCart.id);
          await fetchCartItems(userCart.id);
        } else if (sessionId) {
          // User doesn't have a cart but has a session cart
          // Migrate session cart to user cart
          const { data: newCart } = await supabase
            .from('carts')
            .insert({ user_id: user.id })
            .select('id')
            .single();
          
          if (newCart) {
            setCartId(newCart.id);
            
            // Get session cart items
            const { data: sessionCartItems } = await supabase
              .from('cart_items')
              .select('product_id, quantity')
              .eq('cart_id', sessionId);
            
            // Add items to user cart
            if (sessionCartItems && sessionCartItems.length > 0) {
              for (const item of sessionCartItems) {
                await supabase.from('cart_items').insert({
                  cart_id: newCart.id,
                  product_id: item.product_id,
                  quantity: item.quantity
                });
              }
            }
            
            // Delete session cart
            await supabase.from('carts').delete().eq('session_id', sessionId);
            localStorage.removeItem('cartSessionId');
            
            await fetchCartItems(newCart.id);
          }
        } else {
          // Create new cart for user
          const { data: newCart } = await supabase
            .from('carts')
            .insert({ user_id: user.id })
            .select('id')
            .single();
          
          if (newCart) {
            setCartId(newCart.id);
            setItems([]);
          }
        }
      } else if (sessionId) {
        // User is not logged in but has a session cart
        const { data: sessionCart } = await supabase
          .from('carts')
          .select('id')
          .eq('session_id', sessionId)
          .single();
        
        if (sessionCart) {
          setCartId(sessionCart.id);
          await fetchCartItems(sessionCart.id);
        } else {
          // Create new session cart
          createSessionCart();
        }
      } else {
        // Create new session cart
        createSessionCart();
      }
      
      setIsLoading(false);
    };
    
    initializeCart();
  }, [user]);

  const createSessionCart = async () => {
    const sessionId = `session_${Math.random().toString(36).substring(2, 15)}`;
    localStorage.setItem('cartSessionId', sessionId);
    
    const { data: newCart } = await supabase
      .from('carts')
      .insert({ session_id: sessionId })
      .select('id')
      .single();
    
    if (newCart) {
      setCartId(newCart.id);
      setItems([]);
    }
  };

  const fetchCartItems = async (cartId: string) => {
    const { data, error } = await supabase
      .from('cart_items')
      .select(`
        id,
        product_id,
        quantity,
        product:products (
          id,
          title,
          price,
          images,
          slug
        )
      `)
      .eq('cart_id', cartId);
    
    if (error) {
      console.error('Error fetching cart items:', error);
      return;
    }
    
    setItems(data || []);
  };

  const addItem = async (productId: string, quantity = 1) => {
    if (!cartId) return;
    
    // Check if item already exists in cart
    const existingItem = items.find(item => item.product_id === productId);
    
    if (existingItem) {
      // Update quantity
      await updateItem(productId, existingItem.quantity + quantity);
      toast.success('Item quantity updated in cart');
    } else {
      // Add new item
      const { data, error } = await supabase
        .from('cart_items')
        .insert({
          cart_id: cartId,
          product_id: productId,
          quantity
        })
        .select(`
          id,
          product_id,
          quantity,
          product:products (
            id,
            title,
            price,
            images,
            slug
          )
        `)
        .single();
      
      if (error) {
        console.error('Error adding item to cart:', error);
        toast.error('Failed to add item to cart');
        return;
      }
      
      setItems([...items, data]);
      toast.success('Item added to cart');
    }
  };

  const updateItem = async (productId: string, quantity: number) => {
    if (!cartId) return;
    
    if (quantity <= 0) {
      await removeItem(productId);
      return;
    }
    
    const { error } = await supabase
      .from('cart_items')
      .update({ quantity })
      .eq('cart_id', cartId)
      .eq('product_id', productId);
    
    if (error) {
      console.error('Error updating cart item:', error);
      toast.error('Failed to update item quantity');
      return;
    }
    
    setItems(
      items.map(item =>
        item.product_id === productId ? { ...item, quantity } : item
      )
    );
  };

  const removeItem = async (productId: string) => {
    if (!cartId) return;
    
    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('cart_id', cartId)
      .eq('product_id', productId);
    
    if (error) {
      console.error('Error removing cart item:', error);
      toast.error('Failed to remove item from cart');
      return;
    }
    
    setItems(items.filter(item => item.product_id !== productId));
    toast.success('Item removed from cart');
  };

  const clearCart = async () => {
    if (!cartId) return;
    
    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('cart_id', cartId);
    
    if (error) {
      console.error('Error clearing cart:', error);
      toast.error('Failed to clear cart');
      return;
    }
    
    setItems([]);
    toast.success('Cart cleared');
  };

  const value = {
    items,
    isLoading,
    cartId,
    addItem,
    updateItem,
    removeItem,
    clearCart,
    itemCount,
    subtotal
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};